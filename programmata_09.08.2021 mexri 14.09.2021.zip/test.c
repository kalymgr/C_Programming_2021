/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

#define M 3
#define N 2

int main()
{
	int a, b;
	a = 5;
	printf("%d",a);

}


